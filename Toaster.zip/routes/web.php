<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\LogoutController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\SignupController;
use App\Http\Controllers\ToastController;
use App\Http\Controllers\ToastLikeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\UserToastController;
use App\Models\Like;
use App\Models\Toast;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[HomeController::class,'index'])->name('home');
Route::get('/home',[HomeController::class,'index']);

Route::get('/login',[LoginController::class,"index"])->name('login');
Route::post('/login',[LoginController::class,"store"]);

Route::get('/register',[RegisterController::class,"index"])->name('register');
Route::post('/register',[RegisterController::class,"store"]);

Route::post("/logout",[LogoutController::class,"store"])->name('logout');

Route::get("/toast",[ToastController::class,'index'])->name('toast');
Route::get('/toast/{toast}',[ToastController::class,'showToast'])->name("toast.show");
Route::post("/toast",[ToastController::class,'store']);

Route::delete("/toast/{toast}/delete", [ToastController::class,"destroy"])->name("toast.delete");

Route::post("/toast/{toast}/like", [ToastLikeController::class, "store"])->name("like");
Route::delete("/toast/{toast}/like", [ToastLikeController::class, "destroy"]);

Route::get("/user/{user:username}",[UserController::class,"index"])->name("user");
Route::put("/user/{user}/update",[UserController::class,'updateUser'])->name("user.update");