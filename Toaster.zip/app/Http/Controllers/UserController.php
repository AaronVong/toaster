<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function __construct()
    {
        return $this->middleware(['auth'])->only(["updateUser"]);
    }

    public function updateUser(Request $request, User $user){
        $this->authorize('update',$user);
        $newpw = $request->password;
        $this->validate($request, [
            "name" => "required|max:255",
            "phone"=>"required|digits_between:10,11",
            "date" =>"required|date",
        ]);
        User::where('id', $user->id)->update([
            "name" => $request->name,
            "phone" => $request->phone,
            "date"=>$request->date,
        ]);
        if(strlen($newpw)>0){
            User::where('id',$user->id)->update([
                "password" => Hash::make($request->password)
            ]);
        }
        return back();
    }

    public function index(User $user){
        $userToasts = $user->toasts()->latest()->with(['user','likes'])->simplePaginate(6);
        return view("user.profile",["user"=>$user, 'toasts' => $userToasts]);
    }
}
