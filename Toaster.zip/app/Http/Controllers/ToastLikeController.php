<?php

namespace App\Http\Controllers;

use App\Models\Toast;
use Illuminate\Http\Request;

class ToastLikeController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function store(Toast $toast, Request $req){
        $toast->likes()->create(["user_id" => $req->user()->id]);
        return back();
    }

    public function destroy(Toast $toast, Request $req){
        $req->user()->likes()->where("toast_id", $toast->id)->delete();
        return back();
    }
}
