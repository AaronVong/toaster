$(document).ready(() => {
    let modal = $(".modal");
    let modalId = "";
    let modalBtn = $(".modal__btn");
    let clostBtn = $(".modal__close");
    let navUserControl = $(".nav__user-control");
    let userControls = $(".user-control__controls");
    let formToastBtn = $(".actions__toast");
    let toastsDashboard = $("#toast-dashboard");
    let toastFormTextarea = $("textarea[name='content']");
    let profileShowMoreBtn = $(".profile__show-info");
    let emojiOpenBtn = $(".emoji-picker-btn");
    let emojiPanel = $(".emoji-picker-panel");
    let layer = $("#layer");
    let useUpdateBtn = $("#updateuser");
    /*logout menu*/
    navUserControl.click(() => {
        userControls.toggle();
    });
    /* window click */
    $(window).click((event) => {
        const target = $(event.target);
        // đóng modal khi click bên ngoài
        if (target.prop("id") == modalId && modalId !== "") {
            if (isEmojipanelOpen) {
                emojiPanel.hide();
                isEmojipanelOpen = false;
                layer.hide();
                return;
            }
            modal.hide();
            modalId = "";
        }

        if (target.prop("id") == "layer") {
            emojiPanel.hide();
            isEmojipanelOpen = false;
            target.hide();
        }

        if (
            event.target.classList.contains("modal__content") &&
            isEmojipanelOpen
        ) {
            emojiPanel.hide();
            isEmojipanelOpen = false;
            layer.hide();
        }
    });
    /* Modal */
    modalBtn.mouseup((e) => {
        // hiện modal
        modalId = e.currentTarget.getAttribute("modal");
        $(`#${modalId}`).show();
        console.log($(`#${modalId}`));
    });
    clostBtn.click(() => {
        // đóng modal khi nhấn đóng
        modal.hide();
        modalId = "";
    });
    /* Cuộn để load thêm toast */
    toastsDashboard.infiniteScroll({
        path: "a[rel='next']",
        append: ".toast",
        history: false,
        hideNav: "nav[role='navigation']",
        status: ".page-load-status",
    });

    /* kích hoạt nút toast khi nhập nội dung*/
    toastFormTextarea.keyup((e) => {
        let value = e.target.value;
        if (value !== "") {
            formToastBtn.prop("disabled", false);
            formToastBtn.removeClass("disabled-btn");
        } else {
            formToastBtn.prop("disabled", true);
            formToastBtn.addClass("disabled-btn");
        }
    });

    // hiện thêm thông tin ở trang cá nhân
    let showinfoClicked = false;
    profileShowMoreBtn.click((e) => {
        showinfoClicked = !showinfoClicked;
        if (showinfoClicked) {
            e.currentTarget.innerText = "Ẩn bớt";
        } else {
            e.currentTarget.innerText = "Thêm...";
        }
        $(".profile__hidden-info").slideToggle();
    });

    // mở emoji panel
    let isEmojipanelOpen = false;
    emojiOpenBtn.click((e) => {
        let target = e.currentTarget;
        if (isEmojipanelOpen) {
            $(target.nextElementSibling).hide();
            layer.hide();
            return;
        }
        $(target.nextElementSibling).show();
        isEmojipanelOpen = true;
        $("#layer").show();
    });
    // nối emoji vừa chòn vào textarea
    $("emoji-picker").on("emoji-click", (e) => {
        let emoji = e.detail["unicode"];
        let value = toastFormTextarea.val() + emoji;
        toastFormTextarea.val(value);
    });
});
