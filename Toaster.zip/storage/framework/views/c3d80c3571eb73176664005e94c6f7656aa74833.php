
<?php $__env->startSection('content'); ?>
<div class="app container grid grid-cols-4 md:auto-cols-min">
    <!-- Navigator -->
    <div class="relative flex w-full justify-center grid-cols-1">
        <?php echo $__env->make("nav.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- App Contents -->
    <div class="col-span-3 lg:col-span-2 relative">
        <h1 class="fz-6 border-b border-gray-500 font-bold text-3xl p-2">Home</h1>
        <section id="toast-detail">
            <?php echo $__env->make("toast.toast",$toast, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </section>
    </div>
    <!-- Sidebar -->
    <div id="sidebar" class="relative grid-cols-1">
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\Toaster\resources\views/toast/showtoast.blade.php ENDPATH**/ ?>