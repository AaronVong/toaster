
<?php $__env->startSection('content'); ?>
<div class="app container grid grid-cols-4 md:auto-cols-min">
    <!-- Navigator -->
    <div class="relative flex w-full justify-center grid-cols-1">
        <?php echo $__env->make("nav.nav", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <!-- App Contents -->
    <div class="col-span-3 lg:col-span-2 relative">
        <div class="w-full flex divide-x divide-gray-500 p-3 bg-gray-900">
            <div class="flex-shrink-0 flex-grow-0 w-1/6">
                <div class="toast__left flex-grow-0 flex-shrink-0 max-w-xs px-2 pt-2">
                    <img src="https://via.placeholder.com/50" class="block w-full rounded-full" />
                </div>
            </div>
            <div class="flex-shrink-1 flex-grow-1 w-5/6">
                <div class="card w-full">
                    <div class="w-full">
                        <ul class="list-none px-2 py-4">
                            <li><span class="font-bold text-lg"><?php echo e($user->name); ?></span></li>
                            <li><span class="font-bold"><?php echo e($user->username); ?></span></li>
                            <li><span class="text-gray-500">Tham gia: </span> <span class="font-bold"><?php echo e($user->created_at); ?></span></li>
                            <li><span class="text-gray-500">Likes nhận được: </span>  <span class="font-bold"><?php echo e($user->recivedLikes()->count()); ?></span></li>
                            <li><span class="text-gray-500">Toast đã đăng: </span>  <span class="font-bold"><?php echo e($toasts->count()); ?> <?php echo e(Str::plural('toast',$toasts->count())); ?></span></li>
                            <button type='button' class="profile__show-info"><span>Thêm...</span></button>
                            <li class="profile__hidden-info hidden">
                                <ul>
                                    <li><span class="text-gray-500">Sinh ngày: </span><span class="font-bold"><?php echo e($user->date); ?></span></li>
                                    <li><span class="text-gray-500">Liên lạc: </span><span class="font-bold"><?php echo e($user->phone); ?></span></li>
                                    <li><span class="text-gray-500">Email: </span><span class="font-bold"><?php echo e($user->email); ?></span></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update',$user)): ?>
                                <button type="button" class="modal__btn focus:outline-none bg-gray-500 rounded-full p-2 w-32 text-white hover:bg-gray-600" modal="editprofile">Chỉnh sửa</button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <nav class="profile-nav h-12 border-b-2 border-blue-500">
            <ul class="list-none flex h-full">
                <li class="h-full"><a href="#" class="block pill-hover p-5 w-full h-full flex items-center text-xl font-bold hover:text-blue-500">Toasts</a></li>
                <li class="h-full"><a href="#" class="block pill-hover p-5 w-full h-full flex items-center text-xl font-bold hover:text-blue-500">Liked Toasts</a></li>
            </ul>
        </nav>
        <section id="toast-dashboard">
            <?php echo $__env->make('toast.toasts',$toasts, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo e($toasts->links()); ?>

        </section>
    </div>
    <!-- Sidebar -->
    <div id="sidebar" class="relative grid-cols-1">
        <?php echo $__env->make('sidebar.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Educations\WebDevelopment\PHP\Toaster\resources\views/user/profile.blade.php ENDPATH**/ ?>